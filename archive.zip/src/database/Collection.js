const COLLECTIONS ={
    user:"user",
    admin:"admin",
    product:"product"
}

module.exports = COLLECTIONS